Hooks:PostHook(LobbyCodeMenuComponent,"init","always_hide_lobby_code",function(self,ws, fullscreen_ws, node)
	if alive(self._panel) then
		
		--panel is shown again from other sources
		self._panel:hide()
		
		--so set the size to 0 so it's effectively hidden even if it's "shown"
		self._panel:set_size(0,0)
	end
end)
