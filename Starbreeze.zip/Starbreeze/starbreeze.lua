    local WINDLCManager_verify_dlcs = WINDLCManager._verify_dlcs
 
    function WINDLCManager:_verify_dlcs()
        WINDLCManager_verify_dlcs(self)
 
        for dlc_name, dlc_data in pairs(Global.dlc_manager.all_dlc_data) do
            if dlc_data.external or not dlc_data.app_id or dlc_data.app_id == "218620" then
                dlc_data.verified = true
            end
        end
        
    end
    
    local WinSteamDLCManager_check_dlc_data = WinSteamDLCManager._check_dlc_data
    
    function WinSteamDLCManager:_check_dlc_data(dlc_data)
        if dlc_data.verified then
            return true
        end
        
        return WinSteamDLCManager_check_dlc_data(self, dlc_data)
    end