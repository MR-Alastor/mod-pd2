# Continental Coins
### _Payday 2 Mod_

Simple mod that allows to modify your current balance of continental coins.
Go to _Mod Options_ > _Continental Coins_

## Requirements
* [BLT](https://paydaymods.com/download/)

## Misc
This mod is provided _as it is_. What you do with this mod is _your_ responsability.
