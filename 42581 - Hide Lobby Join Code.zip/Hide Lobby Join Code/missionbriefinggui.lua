Hooks:PostHook(MissionBriefingGui,"close","hide_lobby_join_code",function(self)
	if self._lobby_code_text then
		self._lobby_code_text:close()
	end
end)