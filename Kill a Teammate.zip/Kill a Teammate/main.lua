function errmsg(msg) managers.chat:_receive_message(1, "ERROR", msg, Color(0.8,0,0), false) end

function kill_mate(peer)
    if not peer:unit() then
        errmsg(peer:name() .. " has no unit.")
        return
    end
    peer:send("sync_friendly_fire_damage", peer:id(), peer:unit(), 900000, "fire")
end

function peer_selection(clbk)
    local params_array = {}
    local peer

    for i=1,4 do
        peer = managers.network:session():peer(i)
        if peer and (peer ~= managers.network:session():local_peer()) then
            params_array[#params_array+1] = {text = peer:name(), data = peer, callback = clbk}
        end
    end
    if #params_array == 0 then
        errmsg("No players.")
        return
    end

    params_array[#params_array+1] = {}
    params_array[#params_array+1] = {text = "Cancel"}

    local menu = QuickMenu:new( "Player Selection", "Select a player to kill.", params_array )
    menu:Show()
end

peer_selection(kill_mate)